$(document).ready(function () {
    if ($('#txtSMS').length !== 0) {
        $('#txtSMS').mask('(000) 000 - 0000');
    }
});